<?php 

 return [ 
    
    /*
    |--------------------------------------------------------------------------
    | Sale Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for Sale CRUD operations.
    |
    */

"sale" => "المبيعات",
"sells" => "المبيعات",
"list_sale" => "قائمة المبيعات",
"add_sale" => "إضافة بيع",
"pos_sale" => "نقطة بيع",
"draft_added" => "تمت إضافة المسودة بنجاح",
"invoice_added" => "تمت إضافة الفاتورة بنجاح",
"item" => "عناصر",
"total" => "المجموع",
"order_tax" => "ضريبة الطلبية",
"discount" => "الخصم",
"total_payable" => "الاجمالى",
"cancel" => "إلغاء",
"draft" => "مسودة",
"finalize" => "دفع واستكمال",
"express_finalize" => "استكمال </br> سريع",
"product" => "منتج",
"products" => "المنتجات",
"unit_price" => "سعر الوحدة",
"qty" => "الكمية",
"subtotal" => "المجموع",
"recent_transactions" => "معاملاتك الأخيرة",
"pos_sale_added" => "تمت إضافة عملية البيع بنجاح",
"price_inc_tax" => "السعر شامل الضريبة",
"tax" => "الضريبية",
"edit_discount" => "تعديل الخصم",
"edit_order_tax" => "تعديل ضريبة الطلبية",
"discount_type" => "نوع الخصم",
"discount_amount" => "مبلغ الخصم",
"no_recent_transactions" => "لا توجد معاملات حديثة",
"final" => "انهاء",
"invoice_no" => "الفاتورة رقم.",
"customer_name" => "اسم العميل",
"payment_status" => "حالة الدفع",
"status" => "الحالة",
"total_amount" => "الاجمالى",
"total_paid" => "المدفوع",
"total_remaining" => "المتبقى",
"payment_info" => "معلومات الدفع",
"drafts" => "المسودات",
"all_drafts" => "جميع المسودات",
"sell_details" => "تفاصيل المبيعات",
"payments" => "المدفوعات",
"amount" => "المبلغ",
"payment_mode" => "طريقة الدفع",
"payment_note" => "ملاحظة الدفع",
"sell_note" => "ملاحظة البيع",
"staff_note" => "ملاحظة الموظفين",
"draft_updated" => "تم تحديث المسودة بنجاح",
"pos_sale_updated" => "تم تحديث البيع بنجاح",
"location" => "الفرع",
"add_payment_row" => "أضف صف دفع",
"finalize_payment" => "انهاء المبيعة",
"sale_date" => "تاريخ البيع",
"list_pos" => "قائمة نقطة البيع",
"edit_sale" => "تعديل البيع",
"shipping"=>"شحن",
"shipping_details"=>"تفاصيل الشحن",
"shipping_charges"=>"رسوم الشحن",
'pos_sales' => 'مبيعات نقطة البيع',

'pending' => 'قيد الانتظار',
'issue_date' => 'تاريخ الإصدار',

];
