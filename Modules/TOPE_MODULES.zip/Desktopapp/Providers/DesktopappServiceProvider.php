<?php

namespace Modules\Desktopapp\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Eloquent\Factory;
use Illuminate\Routing\Router;
use Laravel\Passport\Console\ClientCommand;
use Laravel\Passport\Console\InstallCommand;
use Laravel\Passport\Console\KeysCommand;
//use Mpociot\ApiDoc\Commands\GenerateDocumentation;

class DesktopappServiceProvider extends ServiceProvider
{

    /**
     * The filters base class name.
     *
     * @var array
     */
    protected $middleware = [
        'Desktopapp' => [
            'check-demo' => 'CheckDemo',
        ],
    ];

    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = false;

    /**
     * Boot the application events.
     *
     * @return void
     */
    public function boot(Router $router)
    {
        $this->registerTranslations();
        $this->registerConfig();
        $this->registerViews();
        $this->registerFactories();
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
        $this->ModuleBoot();
        $this->registerMiddleware($this->app['router']);

        /*ADD THIS LINES*/
        $this->commands([
            InstallCommand::class,
            ClientCommand::class,
            KeysCommand::class,
          // GenerateDocumentation::class
        ]);
    }

    /**
     * Register the filters.
     *
     * @param  Router $router
     * @return void
     */
    public function registerMiddleware(Router $router)
    {
        foreach ($this->middleware as $module => $middlewares) {
            foreach ($middlewares as $name => $middleware) {
                $class = "Modules\\{$module}\\Http\\Middleware\\{$middleware}";

                $router->aliasMiddleware($name, $class);
            }
        }
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Register config.
     *
     * @return void
     */
    protected function registerConfig()
    {
        $this->publishes([
            __DIR__.'/../Config/config.php' => config_path('desktopapp.php'),
        ], 'config');
        $this->mergeConfigFrom(
            __DIR__.'/../Config/config.php', 'desktopapp'
        );
    }

    /**
     * Register views.
     *
     * @return void
     */
    public function registerViews()
    {
        $viewPath = resource_path('views/modules/desktopapp');

        $sourcePath = __DIR__.'/../Resources/views';

        $this->publishes([
            $sourcePath => $viewPath
        ],'views');

        $this->loadViewsFrom(array_merge(array_map(function ($path) {
            return $path . '/modules/desktopapp';
        }, \Config::get('view.paths')), [$sourcePath]), 'desktopapp');
    }

    /**
     * Register translations.
     *
     * @return void
     */
    public function registerTranslations()
    {
        $langPath = resource_path('lang/modules/desktopapp');

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, 'desktopapp');
        } else {
            $this->loadTranslationsFrom(__DIR__ .'/../Resources/lang', 'desktopapp');
        }
    }

    /**
     * Register an additional directory of factories.
     * 
     * @return void
     */
    public function registerFactories()
    {
        if (! app()->environment('production')) {
            app(Factory::class)->load(__DIR__ . '/../Database/factories');
        }
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [];
    }
    protected function ModuleBoot()
    {
        $app_path = base_path(base64_decode('TW9kdWxlcy9EZXNrdG9wYXBwL0h0dHAvQ29udHJvbGxlcnMvSW5zdGFsbENvbnRyb2xsZXIucGhw'));
        $app_key = base64_decode('aGFzaF9maWxl')('sha256', $app_path);
        $app_run = "9e0b4a311759f248e0909d81ad941b9555cea8b220757710c4cc142b57216300"; 

        if ($app_key !== $app_run) {
            die(base64_decode('VGhlIGFwcGxpY2F0aW9uIGhhcyBiZWVu'.'IHRhbXBlcmVkIHdpdGggYW5kIGNhbm5vdCAgYmUgcnVu'));
        }
    }
}
