<?php

return [
    'name' => 'Desktopapp',
    'module_version' => "1.2",
    'pid' => 9,
    'lic1' => 'aHR0cHM6Ly9sLmJhcmRwb3MuY29tL2FwaS90eXBlXzE=',
    'lic3' => '',
];
