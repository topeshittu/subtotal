@if($__is_repair_enabled)
	@can("repair.create")
	                                      <li class="nav-item">

		<a href="{{ action([\App\Http\Controllers\SellPosController::class, 'create']). '?sub_type=repair'}}" 
		title="{{ __('repair::lang.add_repair') }}" data-toggle="tooltip" data-placement="bottom" class="">
			<i class="fa fa-wrench fa-lg"></i>
		
		</a>
		</li>
	@endcan
@endif