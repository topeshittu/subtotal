<?php

return [
    'name' => 'Desktopapp',
    'module_version' => "1.0",
    'pid' => 29,
    'lic1' => 'aHR0cHM6Ly9sLnBubi5zb2x1dGlvbnMvYXBpL3R5cGVfMQ==',
];
