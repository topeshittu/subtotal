<?php

namespace Modules\Desktopapp\Transformers;

use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceLayoutResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $array = parent::toArray($request);

        $baseUrl = env('MAIN_APP_URL'); 
        $array['logo'] = !empty($array['logo']) ? base64_encode(@file_get_contents($baseUrl . '/uploads/invoice_logos/' . $array['logo'])) : null;

        
        return $array;
    }
}
