
<section class="no-print">
    <nav class="navbar navbar-default bg-white m-4">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="{{ action([\Modules\Desktopapp\Http\Controllers\ClientController::class, 'index']) }}"><i class="fa fas fa-users-cog"></i> {{__('desktopapp::lang.desktopapp_clients')}}</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li @if(request()->segment(1) == 'desktopapp' && request()->segment(1) == 'client') class="active" @endif>
                    <a href="{{ action([\Modules\Desktopapp\Http\Controllers\ClientController::class, 'index']) }}">@lang('desktopapp::lang.clients')</a>
                    </li>

                    </ul>

            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>
</section>